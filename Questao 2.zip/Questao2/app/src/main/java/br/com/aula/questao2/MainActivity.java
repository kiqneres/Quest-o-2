package br.com.aula.questao2;



import android.os.Bundle;

import android.view.View;

import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;



public class MainActivity extends AppCompatActivity {



    EditText editSalario;

    RadioGroup radioGroup;

    Button btnCalcular;

    TextView textResultado;



    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);



        editSalario = findViewById(R.id.editSalario);

        radioGroup = findViewById(R.id.radioGroup);

        btnCalcular = findViewById(R.id.btnCalcular);

        textResultado = findViewById(R.id.textResultado);



        btnCalcular.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View view) {

                String salarioStr = editSalario.getText().toString();



                if (salarioStr.isEmpty()) {

                    Toast.makeText(MainActivity.this, "Digite o salário", Toast.LENGTH_SHORT).show();

                    return;

                }



                double salario = Double.parseDouble(salarioStr);

                double percentual = 0;



                int checkedId = radioGroup.getCheckedRadioButtonId();

                if (checkedId == R.id.radio40) {

                    percentual = 0.40;

                } else if (checkedId == R.id.radio45) {

                    percentual = 0.45;

                } else if (checkedId == R.id.radio50) {

                    percentual = 0.50;

                } else {

                    Toast.makeText(MainActivity.this, "Selecione um percentual", Toast.LENGTH_SHORT).show();

                    return;

                }



                double novoSalario = salario + (salario * percentual);

                textResultado.setText(String.format("Novo salário: R$ %.2f", novoSalario));

            }

        });

    }

}